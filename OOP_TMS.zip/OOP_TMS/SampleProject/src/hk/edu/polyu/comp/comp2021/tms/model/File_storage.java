package hk.edu.polyu.comp.comp2021.tms.model;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 */
public class File_storage {
    /**
     *
     */
    private static boolean exist = false;

    /**
     * @param c
     * @throws IOException
     */
    public static void store(String[] c) throws IOException {

        if (c.length != 2) {
            System.out.println("Wrong input length.");
        } else {
            String p = c[1];
            List<Map<String, String>> list = new ArrayList<Map<String, String>>();
            for (Task t : TMS.tasks) {
                Map<String, String> map = new HashMap<String, String>();
                if (t.getClass().equals(CompositeTask.class)) {
                    String temp = "";
                    for (Task a : ((CompositeTask) t).subtask) {
                        temp = temp + "," + a.name;
                    }
                    map.put("CreateCompositeTask", t.name + " " + t.description + " " + temp.substring(1));
                    list.add(map);
                } else if (t.getClass().equals(PrimitiveTask.class)) {
                    String temp = "";
                    if (((PrimitiveTask) t).prerequisite.isEmpty()) {
                        map.put("CreatePrimitiveTask", t.name + " " + t.description + " " + t.duration + " ,");
                        list.add(map);
                    } else {
                        for (Task b : ((PrimitiveTask) t).prerequisite) {
                            temp = temp + "," + b.name;
                        }
                        map.put("CreatePrimitiveTask", t.name + " " + t.description + " " + t.duration + " "
                                + temp.substring(1));
                        list.add(map);
                    }
                }
            }
            for (Criterion t : CriteriaStorage.getcriteria()) {
                if(t.getClass().equals(IsPrimitiveCriterion.class)){
                    continue;
                }
                Map<String, String> map = new HashMap<String, String>();
                if (t.getClass().equals(BasicCriterion.class)) {
                    map.put("DefineBasicCriterion", t.getName() + " " + t.getProperty_name()
                            + " " + t.getOp() + " " + t.getValue().getResult());
                    list.add(map);
                }
                else {
                    Criterion[] m = ((BinaryCriterion) t).getDualCriteria();
                    map.put("DefineBinaryCriterion", t.name + " " + m[0].name + " "
                            + ((BinaryCriterion) t).getLogicOp() + " " + m[1].name);
                    list.add(map);
                }
            }


            try {
                File file = new File(p);
                FileOutputStream fos = null;
                if (file.exists() && exist == false) {
                    System.out.println("There is a file exist on the given path, please change the path");
                } else {
                    if (!file.exists()) {
                        exist = true;
                        if (file.createNewFile()) System.out.println("File has been created.");
                        else System.out.println("File creation falied.");
                        fos = new FileOutputStream(file);
                    } else {
                        System.out.println("Data has been added.");
                        fos = new FileOutputStream(file);
                    }
                    OutputStreamWriter osw = new OutputStreamWriter(fos);
                    for (Map<String, String> map : list) {
                        for (Map.Entry<String, String> entry : map.entrySet()) {
                            String str = entry.getKey() + " " + entry.getValue();
                            osw.write(str);
                        }
                        osw.write("\r\n");
                    }
                    osw.close();
                    System.out.println("Data has been stored.");
                    System.out.println("-----------------------------------");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}


