package hk.edu.polyu.comp.comp2021.tms.model;

import org.junit.Test;

public class TMSTest {

    @Test
    public void testTMSConstructor(){
        TMS tms = new TMS();

    }



}