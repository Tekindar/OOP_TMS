package hk.edu.polyu.comp.comp2021.tms.controller;

public interface Create {
    void createBasicCriterion (String []command);
    void createNegatedCriterion (String []command);
    void createBinaryCriterion (String []command);
}
