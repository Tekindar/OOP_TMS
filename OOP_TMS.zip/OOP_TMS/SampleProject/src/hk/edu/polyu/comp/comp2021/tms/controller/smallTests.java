package hk.edu.polyu.comp.comp2021.tms.controller;

public class smallTests {

    static int a(int b){
        b += 2;
        return b;
    }
    public static void main(String[] args) {
        System.out.println(a(2));
    }
}
