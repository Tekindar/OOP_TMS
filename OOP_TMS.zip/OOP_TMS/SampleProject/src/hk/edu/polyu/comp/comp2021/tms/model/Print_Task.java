package hk.edu.polyu.comp.comp2021.tms.model;

public class Print_Task {
    public static void print_one(String taskname){
        Task t = null;
        boolean exist = false;
        for(Task a:TMS.tasks){
            if(a.name.equals(taskname)){
                t = a;
                exist = true;
                break;
            }
        }
        if(!exist){
            System.out.println("Task not found");
            return;
        }
        System.out.println("The name of the Task: "+t.name);
        if(t instanceof PrimitiveTask){
            System.out.println("This is a Primitive Task");
            if(((PrimitiveTask) t).prerequisite.isEmpty()){
                System.out.println("It doesn't have any prerequisite task");
            }
            else {
                System.out.print("It has ");
                for (Task a : ((PrimitiveTask) t).prerequisite) {
                    System.out.print(a.name + " ");
                }
                System.out.println("as its prerequisite task(s)");
            }
        }
        else {
            System.out.println("This is a Composite Task");
            System.out.print("It has ");
            for (Task a : ((CompositeTask) t).subtask) {
                System.out.print(a.name + " ");
            }
            System.out.println("as its subtasks");
        }
        System.out.println("The duration of the Task: "+t.duration);
        System.out.println("The description of the Task: "+t.description);
    }
    public static void printAll(){
        for(Task t: TMS.tasks){
            print_one(t.name);
            System.out.println("------------------------------------------------------------------");
        }
    }
    public static void printone(String[] a){
        if(a.length!=2){
            System.out.println("Wrong input length");
        }
        print_one(a[1]);
    }
}
