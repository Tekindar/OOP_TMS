package hk.edu.polyu.comp.comp2021.tms.controller;

import java.util.LinkedList;

public interface Search {
    LinkedList<String> search (String []command);
}
